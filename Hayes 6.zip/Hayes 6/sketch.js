function setup() {
  	
  	createCanvas(400, 400);
	background(135);

 let num = 10;

 let newNum = returnValue(num);

 print(newNum);

}



function draw() {
  	
	angleMode(DEGREES);

	let a = 75;
	

  	for(let i = 0; i < 4; i++){
			cloud(a, 50);
			a = a + 85;
			scale(1.2, 1.1);
			rotate(5);
			
	}

}

function cloud( x, y ) {

	push();

	translate(x,y);

	strokeWeight(5);

	stroke(220);

	line(0, 35, 20, 75);
	line(20, 75, -20, 150);
	line(-20, 150, 20, 225);
	line(20, 225, -20, 300);
	line(-20, 300, 20, 375);

	noStroke();
	fill(65);
	ellipse(0, 0, 65, 50);
	ellipse(-20, 20, 65, 50);
	ellipse(20, 20, 65, 50);

	pop();

}

function returnValue(c) {


	var value = c + 12;

	return value;

}