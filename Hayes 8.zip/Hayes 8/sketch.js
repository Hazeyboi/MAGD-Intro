var pic1;
var pic2;
var pic3;


function preload(){

	pic1 = loadImage("lake2.jpeg");
	pic2 = loadImage("bridge.jpeg");
	pic3 = loadImage("sunset.gif");
}

function setup() {
  

 createCanvas(800, 800);

 background(75);

}



function draw() {
  	
  	
  	stroke(5);

  	fill(255);

  	textSize(28);	

  	textFont("Gotham");

	text("I never go back on my word!", 25, 10, 200, 200);

	textFont("Mclaren");

	text("Believe it!", 450, 90);
	
	
	image(pic2, 20, 100, 800, 800);

	image(pic1, 20, 100, mouseX, mouseY);


	image(pic3, 400, mouseY);
	
}

