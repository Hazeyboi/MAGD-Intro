function setup() {
 	
 	createCanvas(600, 600);
 	background(50);
 	
}

function draw() {
  
	noStroke();

	let x = 150;
	let y = 300;
	let r = 100;
	
	ellipse(x, y, r, r);

	if(keyIsPressed)
	{
  		for( let i = 1; i < 5; i++)
  		{

  			
  			
  			fill(255);
  			ellipse(x, y, r, r);
  			x = x + 150

  			


  		}


  	}
  	else if(mouseIsPressed)
  	{
  		fill(255);
  		ellipse(x, y + 250, r, r);

  		fill(50);
  		ellipse(x, y, r + 5, r + 5);


  	}


 }


